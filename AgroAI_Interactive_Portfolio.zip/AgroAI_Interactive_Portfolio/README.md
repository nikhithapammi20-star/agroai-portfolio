# AgroAI — AI-Powered Smart Agriculture Portfolio

A responsive, single-page interactive website made with HTML, CSS, and JavaScript.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a modern web browser.
3. Internet access is needed for the Unsplash photography used in the design. The page and interactions otherwise run locally.

## Interactive features
- Responsive navigation and mobile menu
- Smooth-scroll section links and active navigation state
- Interactive sample farm dashboard with four field-condition scenarios
- Dynamic chart and status indicators
- Contact form validation with a demo confirmation (does not send or store messages)

## Important
AgroAI is a student concept portfolio. Dashboard readings and possible benefits are illustrative, not live sensor data or validated research results.
